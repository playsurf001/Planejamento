#!/usr/bin/env python3
"""
Script para importar dados da planilha Excel para o banco D1 (SQLite local)
"""
import pandas as pd
import sqlite3
from datetime import datetime
import os

# Caminhos
EXCEL_FILE = '/home/user/uploaded_files/controle_producao1.xlsx'
DB_PATH = '/home/user/webapp/.wrangler/state/v3/d1/miniflare-D1DatabaseObject'

def find_db_file():
    """Encontra o arquivo do banco de dados D1 local"""
    wrangler_dir = '/home/user/webapp/.wrangler/state/v3/d1'
    if os.path.exists(wrangler_dir):
        for root, dirs, files in os.walk(wrangler_dir):
            for file in files:
                if file.endswith('.sqlite'):
                    return os.path.join(root, file)
    return None

def import_lancamentos():
    """Importa lançamentos da planilha para o banco"""
    print("Carregando planilha Excel...")
    
    # Ler aba de lançamentos
    df = pd.read_excel(EXCEL_FILE, sheet_name='Lançamentos')
    
    # Encontrar banco de dados
    db_file = find_db_file()
    if not db_file:
        print("Erro: Banco de dados D1 local não encontrado!")
        print("Execute primeiro: npm run db:migrate:local")
        return
    
    print(f"Conectando ao banco: {db_file}")
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()
    
    # Mapear designers e produtos para IDs
    designers_map = {}
    cursor.execute("SELECT id, nome FROM designers")
    for row in cursor.fetchall():
        designers_map[row[1]] = row[0]
    
    produtos_map = {}
    cursor.execute("SELECT id, nome FROM produtos")
    for row in cursor.fetchall():
        produtos_map[row[1]] = row[0]
    
    print(f"\nDesigners no banco: {list(designers_map.keys())}")
    print(f"Produtos no banco: {list(produtos_map.keys())}")
    
    # Processar cada coluna de lançamento
    # A planilha tem múltiplos conjuntos de colunas repetidas
    total_imported = 0
    
    for col_group in range(0, len(df.columns), 7):
        # Verificar se existe coluna Designer neste grupo
        cols = df.columns[col_group:col_group+7]
        
        # Procurar colunas relevantes
        designer_col = None
        produto_col = None
        data_col = None
        semana_col = None
        criada_col = None
        aprovada_col = None
        
        for col in cols:
            col_str = str(col).lower()
            if 'designer' in col_str:
                designer_col = col
            elif 'produto' in col_str:
                produto_col = col
            elif 'data' in col_str and 'data' not in col_str.lower().replace('data', ''):
                data_col = col
            elif 'semana' in col_str:
                semana_col = col
            elif 'criada' in col_str:
                criada_col = col
            elif 'aprovada' in col_str:
                aprovada_col = col
        
        # Se não encontrou colunas essenciais, pular este grupo
        if not designer_col or not produto_col:
            continue
        
        print(f"\nProcessando grupo de colunas: {designer_col}, {produto_col}...")
        
        # Processar cada linha
        for idx, row in df.iterrows():
            try:
                designer_nome = row[designer_col]
                produto_nome = row[produto_col]
                
                # Pular linhas vazias
                if pd.isna(designer_nome) or pd.isna(produto_nome):
                    continue
                
                # Mapear para IDs
                designer_id = designers_map.get(designer_nome)
                produto_id = produtos_map.get(produto_nome)
                
                if not designer_id or not produto_id:
                    print(f"Pulando linha {idx}: Designer ou Produto não encontrado ({designer_nome}, {produto_nome})")
                    continue
                
                # Extrair outros campos
                data = row[data_col] if data_col and not pd.isna(row[data_col]) else datetime.now().date()
                semana = int(row[semana_col]) if semana_col and not pd.isna(row[semana_col]) else 1
                quantidade_criada = int(row[criada_col]) if criada_col and not pd.isna(row[criada_col]) else 0
                quantidade_aprovada = int(row[aprovada_col]) if aprovada_col and not pd.isna(row[aprovada_col]) else 0
                
                # Converter data se necessário
                if isinstance(data, pd.Timestamp):
                    data = data.date()
                
                # Inserir no banco
                cursor.execute("""
                    INSERT INTO lancamentos 
                    (designer_id, produto_id, semana, data, quantidade_criada, quantidade_aprovada)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (designer_id, produto_id, semana, str(data), quantidade_criada, quantidade_aprovada))
                
                total_imported += 1
                
            except Exception as e:
                print(f"Erro ao processar linha {idx}: {e}")
                continue
    
    # Commit e fechar
    conn.commit()
    conn.close()
    
    print(f"\n✅ Importação concluída! Total de lançamentos importados: {total_imported}")

if __name__ == '__main__':
    import_lancamentos()
