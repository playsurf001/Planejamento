-- Inserir Designers
INSERT OR IGNORE INTO designers (nome) VALUES ('Amanda');
INSERT OR IGNORE INTO designers (nome) VALUES ('Filiphe');
INSERT OR IGNORE INTO designers (nome) VALUES ('Lidivania');
INSERT OR IGNORE INTO designers (nome) VALUES ('Elison');
INSERT OR IGNORE INTO designers (nome) VALUES ('Wellington');
INSERT OR IGNORE INTO designers (nome) VALUES ('Vinicius');

-- Inserir Produtos
INSERT OR IGNORE INTO produtos (nome) VALUES ('VOLLEY SUBLIMADO');
INSERT OR IGNORE INTO produtos (nome) VALUES ('VOLLEY JUVENIL');
INSERT OR IGNORE INTO produtos (nome) VALUES ('BOARDSHORT');
INSERT OR IGNORE INTO produtos (nome) VALUES ('BOARDSHORT JUVENIL');
INSERT OR IGNORE INTO produtos (nome) VALUES ('PASSEIO SUBLIMADO');
INSERT OR IGNORE INTO produtos (nome) VALUES ('BERMUDA MOLETOM');
INSERT OR IGNORE INTO produtos (nome) VALUES ('CAMISETA SUBLIMADA');
INSERT OR IGNORE INTO produtos (nome) VALUES ('CAMISETA ESTAMPADA');
INSERT OR IGNORE INTO produtos (nome) VALUES ('CAMISETA JUVENIL');
INSERT OR IGNORE INTO produtos (nome) VALUES ('REGATA SUBLIMADA');
INSERT OR IGNORE INTO produtos (nome) VALUES ('REGATA ESTAMPADA');
INSERT OR IGNORE INTO produtos (nome) VALUES ('REGATA MACHÃO');
INSERT OR IGNORE INTO produtos (nome) VALUES ('OVERSIDED');

-- Inserir Metas
INSERT OR IGNORE INTO metas (produto_id, meta_aprovacao, periodo_semanas) 
VALUES ((SELECT id FROM produtos WHERE nome = 'BOARDSHORT'), 108, 18);

INSERT OR IGNORE INTO metas (produto_id, meta_aprovacao, periodo_semanas) 
VALUES ((SELECT id FROM produtos WHERE nome = 'VOLLEY SUBLIMADO'), 72, 18);

INSERT OR IGNORE INTO metas (produto_id, meta_aprovacao, periodo_semanas) 
VALUES ((SELECT id FROM produtos WHERE nome = 'CAMISETA SUBLIMADA'), 54, 18);

INSERT OR IGNORE INTO metas (produto_id, meta_aprovacao, periodo_semanas) 
VALUES ((SELECT id FROM produtos WHERE nome = 'REGATA SUBLIMADA'), 54, 18);

INSERT OR IGNORE INTO metas (produto_id, meta_aprovacao, periodo_semanas) 
VALUES ((SELECT id FROM produtos WHERE nome = 'REGATA ESTAMPADA'), 50, 18);

INSERT OR IGNORE INTO metas (produto_id, meta_aprovacao, periodo_semanas) 
VALUES ((SELECT id FROM produtos WHERE nome = 'CAMISETA ESTAMPADA'), 50, 18);

-- Inserir alguns lançamentos de exemplo
INSERT INTO lancamentos (designer_id, produto_id, semana, data, quantidade_criada, quantidade_aprovada)
VALUES (
  (SELECT id FROM designers WHERE nome = 'Amanda'),
  (SELECT id FROM produtos WHERE nome = 'BOARDSHORT'),
  1, '2025-10-06', 2, 2
);

INSERT INTO lancamentos (designer_id, produto_id, semana, data, quantidade_criada, quantidade_aprovada)
VALUES (
  (SELECT id FROM designers WHERE nome = 'Amanda'),
  (SELECT id FROM produtos WHERE nome = 'VOLLEY SUBLIMADO'),
  1, '2025-10-06', 2, 2
);

INSERT INTO lancamentos (designer_id, produto_id, semana, data, quantidade_criada, quantidade_aprovada)
VALUES (
  (SELECT id FROM designers WHERE nome = 'Amanda'),
  (SELECT id FROM produtos WHERE nome = 'CAMISETA SUBLIMADA'),
  1, '2025-10-06', 2, 1
);

INSERT INTO lancamentos (designer_id, produto_id, semana, data, quantidade_criada, quantidade_aprovada)
VALUES (
  (SELECT id FROM designers WHERE nome = 'Amanda'),
  (SELECT id FROM produtos WHERE nome = 'REGATA SUBLIMADA'),
  1, '2025-10-06', 2, 1
);
