-- Adicionar campos de status aos lançamentos
ALTER TABLE lancamentos ADD COLUMN status TEXT DEFAULT 'pendente';
ALTER TABLE lancamentos ADD COLUMN criado_check INTEGER DEFAULT 0;
ALTER TABLE lancamentos ADD COLUMN aprovado_ok INTEGER DEFAULT 0;
ALTER TABLE lancamentos ADD COLUMN posicao TEXT;

-- Criar índice para status
CREATE INDEX IF NOT EXISTS idx_lancamentos_status ON lancamentos(status);
