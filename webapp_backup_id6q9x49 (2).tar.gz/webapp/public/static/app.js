// API Base URL
const API_URL = '';

// Estado global
let designers = [];
let produtos = [];
let periodos = [];
let chartDesigners = null;
let chartTimeline = null;
let currentPage = 0;
let totalItems = 0;
let itemsPerPage = 20;
let currentFilters = {
  mes: '',
  ano: '',
  semana: ''
};

// Navegação entre tabs
function showTab(tabName) {
  // Esconder todas as tabs
  document.querySelectorAll('.tab-content').forEach(tab => {
    tab.classList.add('hidden');
  });
  
  // Mostrar tab selecionada
  document.getElementById(`tab-${tabName}`).classList.remove('hidden');
  
  // Atualizar botões
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.classList.remove('bg-white/40');
  });
  
  // Carregar dados da tab
  if (tabName === 'dashboard') {
    loadDashboard();
  } else if (tabName === 'designers') {
    loadDesignersList();
  } else if (tabName === 'lancamentos') {
    loadLancamentos();
  } else if (tabName === 'relatorios') {
    loadRelatorios();
  } else if (tabName === 'metas') {
    loadMetas();
  } else if (tabName === 'cadastros') {
    loadCadastros();
  }
}

// ===========================
// INICIALIZAÇÃO
// ===========================

async function initializeApp() {
  // Carregar períodos disponíveis
  try {
    const periodosRes = await axios.get(`${API_URL}/api/periodos`);
    periodos = periodosRes.data;
    
    // Preencher selects de filtro
    populateFilterSelects();
  } catch (error) {
    console.error('Erro ao carregar períodos:', error);
  }
  
  // Carregar designers e produtos para os selects
  await loadDesignersAndProdutos();
  
  // Definir data padrão como hoje
  const today = new Date().toISOString().split('T')[0];
  document.getElementById('input-data').value = today;
  
  // Carregar dashboard por padrão
  loadDashboard();
}

async function loadDesignersAndProdutos() {
  try {
    const [designersRes, produtosRes] = await Promise.all([
      axios.get(`${API_URL}/api/designers`),
      axios.get(`${API_URL}/api/produtos`)
    ]);
    
    designers = designersRes.data;
    produtos = produtosRes.data;
    
    // Atualizar todos os selects
    updateDesignerSelects();
    updateProdutoSelects();
  } catch (error) {
    console.error('Erro ao carregar designers e produtos:', error);
  }
}

function updateDesignerSelects() {
  const selects = ['input-designer', 'edit-designer'];
  selects.forEach(selectId => {
    const select = document.getElementById(selectId);
    if (select) {
      select.innerHTML = '<option value="">Selecione...</option>' +
        designers.map(d => `<option value="${d.id}">${d.nome}</option>`).join('');
    }
  });
}

function updateProdutoSelects() {
  const selects = ['input-produto', 'edit-produto', 'meta-produto'];
  selects.forEach(selectId => {
    const select = document.getElementById(selectId);
    if (select) {
      select.innerHTML = '<option value="">Selecione...</option>' +
        produtos.map(p => `<option value="${p.id}">${p.nome}</option>`).join('');
    }
  });
}

function populateFilterSelects() {
  const meses = [...new Set(periodos.map(p => p.mes))].sort();
  const anos = [...new Set(periodos.map(p => p.ano))].sort().reverse();
  
  // Filtros do dashboard
  const filterMes = document.getElementById('filter-mes');
  const filterAno = document.getElementById('filter-ano');
  
  if (filterMes) {
    filterMes.innerHTML = '<option value="">Todos</option>' +
      meses.map(m => `<option value="${m}">${getNomeMes(m)}</option>`).join('');
  }
  
  if (filterAno) {
    filterAno.innerHTML = '<option value="">Todos</option>' +
      anos.map(a => `<option value="${a}">${a}</option>`).join('');
  }
  
  // Filtros de relatórios
  const relatorioMes = document.getElementById('relatorio-mes');
  const relatorioAno = document.getElementById('relatorio-ano');
  
  if (relatorioMes) {
    relatorioMes.innerHTML = '<option value="">Todos</option>' +
      meses.map(m => `<option value="${m}">${getNomeMes(m)}</option>`).join('');
  }
  
  if (relatorioAno) {
    relatorioAno.innerHTML = '<option value="">Todos</option>' +
      anos.map(a => `<option value="${a}">${a}</option>`).join('');
  }
}

function getNomeMes(mes) {
  const meses = {
    '01': 'Janeiro', '02': 'Fevereiro', '03': 'Março',
    '04': 'Abril', '05': 'Maio', '06': 'Junho',
    '07': 'Julho', '08': 'Agosto', '09': 'Setembro',
    '10': 'Outubro', '11': 'Novembro', '12': 'Dezembro'
  };
  return meses[mes] || mes;
}

// ===========================
// DASHBOARD
// ===========================

function applyDashboardFilters() {
  currentFilters.mes = document.getElementById('filter-mes').value;
  currentFilters.ano = document.getElementById('filter-ano').value;
  loadDashboard();
}

function clearDashboardFilters() {
  document.getElementById('filter-mes').value = '';
  document.getElementById('filter-ano').value = '';
  currentFilters.mes = '';
  currentFilters.ano = '';
  loadDashboard();
}

async function loadDashboard() {
  try {
    const params = new URLSearchParams();
    if (currentFilters.mes) params.append('mes', currentFilters.mes);
    if (currentFilters.ano) params.append('ano', currentFilters.ano);
    
    // Carregar estatísticas gerais
    const statsRes = await axios.get(`${API_URL}/api/relatorios/estatisticas?${params}`);
    const stats = statsRes.data;
    
    document.getElementById('stat-designers').textContent = stats.total_designers || 0;
    document.getElementById('stat-aprovadas').textContent = stats.total_aprovadas || 0;
    document.getElementById('stat-criadas').textContent = stats.total_criadas || 0;
    document.getElementById('stat-taxa').textContent = `${stats.taxa_aprovacao_geral || 0}%`;
    
    // Carregar dados para gráfico de designers
    const designersRes = await axios.get(`${API_URL}/api/relatorios/por-designer?${params}`);
    renderChartDesigners(designersRes.data);
    
    // Carregar dados para timeline
    const timelineRes = await axios.get(`${API_URL}/api/relatorios/timeline?limit=12&${params}`);
    renderChartTimeline(timelineRes.data);
    
    // Carregar top 6 produtos mais recentes
    const produtosRes = await axios.get(`${API_URL}/api/relatorios/por-produto?limit=6&${params}`);
    renderTopProdutos(produtosRes.data);
    
  } catch (error) {
    console.error('Erro ao carregar dashboard:', error);
    showNotification('Erro ao carregar dados do dashboard', 'error');
  }
}

function renderChartDesigners(data) {
  const ctx = document.getElementById('chartDesigners');
  
  if (chartDesigners) {
    chartDesigners.destroy();
  }
  
  chartDesigners = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: data.map(d => d.designer),
      datasets: [
        {
          label: 'Aprovadas',
          data: data.map(d => d.total_aprovadas || 0),
          backgroundColor: 'rgba(34, 197, 94, 0.7)',
          borderColor: 'rgba(34, 197, 94, 1)',
          borderWidth: 1
        },
        {
          label: 'Criadas',
          data: data.map(d => d.total_criadas || 0),
          backgroundColor: 'rgba(234, 179, 8, 0.7)',
          borderColor: 'rgba(234, 179, 8, 1)',
          borderWidth: 1
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      scales: {
        y: {
          beginAtZero: true
        }
      },
      plugins: {
        legend: {
          position: 'top'
        }
      }
    }
  });
}

function renderChartTimeline(data) {
  const ctx = document.getElementById('chartTimeline');
  
  if (chartTimeline) {
    chartTimeline.destroy();
  }
  
  // Reverter ordem para mostrar semanas em ordem crescente
  const sortedData = [...data].reverse();
  
  chartTimeline = new Chart(ctx, {
    type: 'line',
    data: {
      labels: sortedData.map(d => `Sem ${d.semana}`),
      datasets: [
        {
          label: 'Aprovadas',
          data: sortedData.map(d => d.total_aprovadas || 0),
          borderColor: 'rgba(34, 197, 94, 1)',
          backgroundColor: 'rgba(34, 197, 94, 0.1)',
          tension: 0.3,
          fill: true
        },
        {
          label: 'Criadas',
          data: sortedData.map(d => d.total_criadas || 0),
          borderColor: 'rgba(234, 179, 8, 1)',
          backgroundColor: 'rgba(234, 179, 8, 0.1)',
          tension: 0.3,
          fill: true
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      scales: {
        y: {
          beginAtZero: true
        }
      },
      plugins: {
        legend: {
          position: 'top'
        }
      }
    }
  });
}

function renderTopProdutos(produtos) {
  const container = document.getElementById('topProdutos');
  
  if (!produtos || produtos.length === 0) {
    container.innerHTML = '<p class="text-gray-500 text-center col-span-3 py-8">Nenhum produto encontrado</p>';
    return;
  }
  
  container.innerHTML = produtos.map((p, index) => {
    const icons = ['fa-trophy text-yellow-500', 'fa-medal text-gray-400', 'fa-medal text-orange-600', 'fa-star text-blue-500', 'fa-star text-purple-500', 'fa-star text-pink-500'];
    const icon = icons[index] || 'fa-star text-gray-500';
    const progressColor = (p.progresso_meta || 0) >= 100 ? 'bg-green-500' : (p.progresso_meta || 0) >= 70 ? 'bg-blue-500' : 'bg-orange-500';
    
    return `
      <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition">
        <div class="flex items-center justify-between mb-3">
          <h4 class="font-semibold text-gray-800 flex items-center text-sm">
            <i class="fas ${icon} mr-2"></i>
            ${p.produto}
          </h4>
          <span class="text-xl font-bold text-green-600">${p.total_aprovadas || 0}</span>
        </div>
        <div class="space-y-2 text-xs">
          <div class="flex justify-between">
            <span class="text-gray-600">Meta:</span>
            <span class="font-medium">${p.meta_aprovacao || 'N/A'}</span>
          </div>
          <div class="flex justify-between">
            <span class="text-gray-600">Taxa Aprovação:</span>
            <span class="font-medium">${p.taxa_aprovacao || 0}%</span>
          </div>
          ${p.progresso_meta ? `
            <div>
              <div class="flex justify-between text-xs mb-1">
                <span>Progresso</span>
                <span class="font-medium">${Math.round(p.progresso_meta)}%</span>
              </div>
              <div class="w-full bg-gray-200 rounded-full h-2">
                <div class="${progressColor} h-2 rounded-full transition-all" style="width: ${Math.min(p.progresso_meta, 100)}%"></div>
              </div>
            </div>
          ` : ''}
          ${p.ultima_atualizacao ? `
            <div class="text-gray-500 text-xs mt-2">
              Atualizado: ${new Date(p.ultima_atualizacao).toLocaleDateString('pt-BR')}
            </div>
          ` : ''}
        </div>
      </div>
    `;
  }).join('');
}

// ===========================
// LANÇAMENTOS
// ===========================

async function loadLancamentos(page = 0) {
  try {
    currentPage = page;
    const semanaFilter = document.getElementById('lancamentos-semana-filter').value;
    
    const params = new URLSearchParams();
    params.append('limit', itemsPerPage);
    params.append('offset', page * itemsPerPage);
    if (semanaFilter) params.append('semana', semanaFilter);
    
    const lancamentosRes = await axios.get(`${API_URL}/api/lancamentos?${params}`);
    const { data, total } = lancamentosRes.data;
    totalItems = total;
    
    renderLancamentos(data);
    renderPagination();
    
    // Atualizar filtro de semanas
    await updateSemanasFilter();
    
  } catch (error) {
    console.error('Erro ao carregar lançamentos:', error);
    showNotification('Erro ao carregar lançamentos', 'error');
  }
}

async function updateSemanasFilter() {
  try {
    const result = await axios.get(`${API_URL}/api/lancamentos?limit=1000`);
    const semanas = [...new Set(result.data.data.map(l => l.semana))].sort((a, b) => b - a);
    
    const select = document.getElementById('lancamentos-semana-filter');
    const currentValue = select.value;
    
    select.innerHTML = '<option value="">Todas Semanas</option>' +
      semanas.map(s => `<option value="${s}">Semana ${s}</option>`).join('');
    
    if (currentValue) select.value = currentValue;
  } catch (error) {
    console.error('Erro ao atualizar filtro de semanas:', error);
  }
}

function renderLancamentos(lancamentos) {
  const container = document.getElementById('listaLancamentos');
  
  if (lancamentos.length === 0) {
    container.innerHTML = '<p class="text-gray-500 text-center py-8">Nenhum lançamento encontrado</p>';
    return;
  }
  
  container.innerHTML = `
    <table class="min-w-full divide-y divide-gray-200">
      <thead class="bg-gray-50">
        <tr>
          <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Semana</th>
          <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Data</th>
          <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Designer</th>
          <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Produto</th>
          <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Criadas</th>
          <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Aprovadas</th>
          <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Taxa</th>
          <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Ações</th>
        </tr>
      </thead>
      <tbody class="bg-white divide-y divide-gray-200">
        ${lancamentos.map(l => {
          const taxa = l.quantidade_criada > 0 ? Math.round((l.quantidade_aprovada / l.quantidade_criada) * 100) : 0;
          const taxaColor = taxa >= 75 ? 'text-green-600' : taxa >= 50 ? 'text-yellow-600' : 'text-red-600';
          
          return `
            <tr class="hover:bg-gray-50">
              <td class="px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-900">${l.semana}</td>
              <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-500">${new Date(l.data).toLocaleDateString('pt-BR')}</td>
              <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-900">${l.designer_nome}</td>
              <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-900">${l.produto_nome}</td>
              <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-900">${l.quantidade_criada}</td>
              <td class="px-4 py-3 whitespace-nowrap text-sm font-semibold text-green-600">${l.quantidade_aprovada}</td>
              <td class="px-4 py-3 whitespace-nowrap text-sm font-medium ${taxaColor}">${taxa}%</td>
              <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
                <button onclick="editLancamento(${l.id})" class="text-blue-600 hover:text-blue-800 mr-3" title="Editar">
                  <i class="fas fa-edit"></i>
                </button>
                <button onclick="deleteLancamento(${l.id})" class="text-red-600 hover:text-red-800" title="Excluir">
                  <i class="fas fa-trash"></i>
                </button>
              </td>
            </tr>
          `;
        }).join('')}
      </tbody>
    </table>
  `;
}

function renderPagination() {
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  const container = document.getElementById('paginationLancamentos');
  
  if (totalPages <= 1) {
    container.innerHTML = '';
    return;
  }
  
  let pages = [];
  
  // Botão anterior
  pages.push(`
    <button onclick="loadLancamentos(${currentPage - 1})" 
            ${currentPage === 0 ? 'disabled' : ''} 
            class="px-4 py-2 border rounded-lg ${currentPage === 0 ? 'bg-gray-100 text-gray-400 cursor-not-allowed' : 'bg-white hover:bg-gray-50'}">
      <i class="fas fa-chevron-left"></i>
    </button>
  `);
  
  // Páginas
  for (let i = 0; i < totalPages; i++) {
    if (i === 0 || i === totalPages - 1 || (i >= currentPage - 2 && i <= currentPage + 2)) {
      pages.push(`
        <button onclick="loadLancamentos(${i})" 
                class="px-4 py-2 border rounded-lg ${i === currentPage ? 'bg-blue-600 text-white' : 'bg-white hover:bg-gray-50'}">
          ${i + 1}
        </button>
      `);
    } else if (i === currentPage - 3 || i === currentPage + 3) {
      pages.push('<span class="px-2">...</span>');
    }
  }
  
  // Botão próximo
  pages.push(`
    <button onclick="loadLancamentos(${currentPage + 1})" 
            ${currentPage >= totalPages - 1 ? 'disabled' : ''} 
            class="px-4 py-2 border rounded-lg ${currentPage >= totalPages - 1 ? 'bg-gray-100 text-gray-400 cursor-not-allowed' : 'bg-white hover:bg-gray-50'}">
      <i class="fas fa-chevron-right"></i>
    </button>
  `);
  
  container.innerHTML = pages.join('');
}

async function editLancamento(id) {
  try {
    const result = await axios.get(`${API_URL}/api/lancamentos/${id}`);
    const lancamento = result.data;
    
    // Preencher modal
    document.getElementById('edit-id').value = lancamento.id;
    document.getElementById('edit-designer').value = lancamento.designer_id;
    document.getElementById('edit-produto').value = lancamento.produto_id;
    document.getElementById('edit-semana').value = lancamento.semana;
    document.getElementById('edit-data').value = lancamento.data.split('T')[0];
    document.getElementById('edit-criada').value = lancamento.quantidade_criada;
    document.getElementById('edit-aprovada').value = lancamento.quantidade_aprovada;
    document.getElementById('edit-obs').value = lancamento.observacoes || '';
    
    // Mostrar modal
    document.getElementById('modalEditLancamento').classList.remove('hidden');
  } catch (error) {
    console.error('Erro ao carregar lançamento:', error);
    showNotification('Erro ao carregar lançamento', 'error');
  }
}

function closeEditModal() {
  document.getElementById('modalEditLancamento').classList.add('hidden');
}

async function deleteLancamento(id) {
  if (!confirm('Deseja realmente excluir este lançamento?')) {
    return;
  }
  
  try {
    await axios.delete(`${API_URL}/api/lancamentos/${id}`);
    showNotification('Lançamento excluído com sucesso!', 'success');
    loadLancamentos(currentPage);
  } catch (error) {
    console.error('Erro ao excluir lançamento:', error);
    showNotification('Erro ao excluir lançamento', 'error');
  }
}

// ===========================
// RELATÓRIOS
// ===========================

async function loadRelatorios() {
  try {
    const mes = document.getElementById('relatorio-mes').value;
    const ano = document.getElementById('relatorio-ano').value;
    
    const params = new URLSearchParams();
    if (mes) params.append('mes', mes);
    if (ano) params.append('ano', ano);
    
    // Relatório por Designer
    const designersRes = await axios.get(`${API_URL}/api/relatorios/por-designer?${params}`);
    renderRelatorioDesigners(designersRes.data);
    
    // Relatório por Produto
    const produtosRes = await axios.get(`${API_URL}/api/relatorios/por-produto?${params}`);
    renderRelatorioProdutos(produtosRes.data);
    
  } catch (error) {
    console.error('Erro ao carregar relatórios:', error);
    showNotification('Erro ao carregar relatórios', 'error');
  }
}

function renderRelatorioDesigners(data) {
  const container = document.getElementById('relatorioDesigners');
  
  if (!data || data.length === 0) {
    container.innerHTML = '<p class="text-gray-500 text-center py-8">Nenhum dado encontrado</p>';
    return;
  }
  
  container.innerHTML = data.map(d => {
    const taxa = d.taxa_aprovacao || 0;
    const taxaColor = taxa >= 75 ? 'bg-green-500' : taxa >= 50 ? 'bg-yellow-500' : 'bg-red-500';
    
    return `
      <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition">
        <h4 class="font-semibold text-gray-800 mb-3 flex items-center">
          <i class="fas fa-user-circle text-blue-600 mr-2"></i>
          ${d.designer}
        </h4>
        <div class="grid grid-cols-2 gap-3 text-sm mb-3">
          <div>
            <p class="text-gray-500">Criadas</p>
            <p class="text-xl font-bold text-gray-800">${d.total_criadas || 0}</p>
          </div>
          <div>
            <p class="text-gray-500">Aprovadas</p>
            <p class="text-xl font-bold text-green-600">${d.total_aprovadas || 0}</p>
          </div>
        </div>
        <div>
          <div class="flex justify-between text-xs mb-1">
            <span>Taxa de Aprovação</span>
            <span class="font-medium">${Math.round(taxa)}%</span>
          </div>
          <div class="w-full bg-gray-200 rounded-full h-2">
            <div class="${taxaColor} h-2 rounded-full transition-all" style="width: ${Math.min(taxa, 100)}%"></div>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

function renderRelatorioProdutos(data) {
  const container = document.getElementById('relatorioProdutos');
  
  if (!data || data.length === 0) {
    container.innerHTML = '<p class="text-gray-500 text-center py-8">Nenhum dado encontrado</p>';
    return;
  }
  
  container.innerHTML = data.map(p => {
    const taxa = p.taxa_aprovacao || 0;
    const progresso = p.progresso_meta || 0;
    const taxaColor = taxa >= 75 ? 'bg-green-500' : taxa >= 50 ? 'bg-yellow-500' : 'bg-red-500';
    const progressoColor = progresso >= 100 ? 'bg-green-500' : progresso >= 70 ? 'bg-blue-500' : 'bg-orange-500';
    
    return `
      <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition">
        <h4 class="font-semibold text-gray-800 mb-3 flex items-center">
          <i class="fas fa-box text-green-600 mr-2"></i>
          ${p.produto}
        </h4>
        <div class="grid grid-cols-3 gap-2 text-sm mb-3">
          <div>
            <p class="text-gray-500 text-xs">Criadas</p>
            <p class="text-lg font-bold text-gray-800">${p.total_criadas || 0}</p>
          </div>
          <div>
            <p class="text-gray-500 text-xs">Aprovadas</p>
            <p class="text-lg font-bold text-green-600">${p.total_aprovadas || 0}</p>
          </div>
          <div>
            <p class="text-gray-500 text-xs">Meta</p>
            <p class="text-lg font-bold text-purple-600">${p.meta_aprovacao || 'N/A'}</p>
          </div>
        </div>
        <div class="space-y-2">
          <div>
            <div class="flex justify-between text-xs mb-1">
              <span>Taxa de Aprovação</span>
              <span class="font-medium">${Math.round(taxa)}%</span>
            </div>
            <div class="w-full bg-gray-200 rounded-full h-2">
              <div class="${taxaColor} h-2 rounded-full transition-all" style="width: ${Math.min(taxa, 100)}%"></div>
            </div>
          </div>
          ${p.meta_aprovacao ? `
            <div>
              <div class="flex justify-between text-xs mb-1">
                <span>Progresso da Meta</span>
                <span class="font-medium">${Math.round(progresso)}%</span>
              </div>
              <div class="w-full bg-gray-200 rounded-full h-2">
                <div class="${progressoColor} h-2 rounded-full transition-all" style="width: ${Math.min(progresso, 100)}%"></div>
              </div>
            </div>
          ` : ''}
        </div>
      </div>
    `;
  }).join('');
}

// Gerar PDF
async function generatePDF() {
  try {
    showNotification('Gerando PDF...', 'info');
    
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    
    // Título
    doc.setFontSize(20);
    doc.text('Relatório de Produção', 20, 20);
    
    // Data
    doc.setFontSize(12);
    const mes = document.getElementById('relatorio-mes').value;
    const ano = document.getElementById('relatorio-ano').value;
    const periodo = mes && ano ? `${getNomeMes(mes)}/${ano}` : 'Todos os períodos';
    doc.text(`Período: ${periodo}`, 20, 30);
    doc.text(`Gerado em: ${new Date().toLocaleDateString('pt-BR')}`, 20, 37);
    
    // Capturar conteúdo do relatório
    const content = document.getElementById('relatorio-content');
    
    await html2canvas(content, {
      scale: 2,
      logging: false,
      useCORS: true
    }).then(canvas => {
      const imgData = canvas.toDataURL('image/png');
      const imgWidth = 170;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      doc.addImage(imgData, 'PNG', 20, 45, imgWidth, imgHeight);
    });
    
    doc.save(`relatorio-producao-${Date.now()}.pdf`);
    showNotification('PDF gerado com sucesso!', 'success');
    
  } catch (error) {
    console.error('Erro ao gerar PDF:', error);
    showNotification('Erro ao gerar PDF', 'error');
  }
}

// ===========================
// METAS
// ===========================

async function loadMetas() {
  try {
    const metasRes = await axios.get(`${API_URL}/api/metas`);
    renderMetas(metasRes.data);
  } catch (error) {
    console.error('Erro ao carregar metas:', error);
    showNotification('Erro ao carregar metas', 'error');
  }
}

function renderMetas(metas) {
  const container = document.getElementById('listaMetas');
  
  if (metas.length === 0) {
    container.innerHTML = '<p class="text-gray-500 text-center py-8">Nenhuma meta cadastrada</p>';
    return;
  }
  
  container.innerHTML = `
    <table class="min-w-full divide-y divide-gray-200">
      <thead class="bg-gray-50">
        <tr>
          <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Produto</th>
          <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Meta de Aprovação</th>
          <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Período (Semanas)</th>
          <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Ações</th>
        </tr>
      </thead>
      <tbody class="bg-white divide-y divide-gray-200">
        ${metas.map(m => `
          <tr class="hover:bg-gray-50">
            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${m.produto_nome}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${m.meta_aprovacao}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${m.periodo_semanas}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
              <button onclick="editMeta(${m.id})" class="text-blue-600 hover:text-blue-800 mr-3" title="Editar">
                <i class="fas fa-edit"></i>
              </button>
              <button onclick="deleteMeta(${m.id})" class="text-red-600 hover:text-red-800" title="Excluir">
                <i class="fas fa-trash"></i>
              </button>
            </td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
}

async function editMeta(id) {
  try {
    const metas = await axios.get(`${API_URL}/api/metas`);
    const meta = metas.data.find(m => m.id === id);
    
    if (!meta) return;
    
    document.getElementById('meta-id').value = meta.id;
    document.getElementById('meta-produto').value = meta.produto_id;
    document.getElementById('meta-aprovacao').value = meta.meta_aprovacao;
    document.getElementById('meta-periodo').value = meta.periodo_semanas;
    
    document.getElementById('meta-form-title').textContent = 'Editar Meta';
    document.getElementById('meta-btn-text').textContent = 'Atualizar Meta';
    document.getElementById('meta-cancel-btn').classList.remove('hidden');
    
    // Scroll para o formulário
    document.getElementById('formMeta').scrollIntoView({ behavior: 'smooth' });
  } catch (error) {
    console.error('Erro ao carregar meta:', error);
    showNotification('Erro ao carregar meta', 'error');
  }
}

function cancelEditMeta() {
  document.getElementById('formMeta').reset();
  document.getElementById('meta-id').value = '';
  document.getElementById('meta-form-title').textContent = 'Nova Meta';
  document.getElementById('meta-btn-text').textContent = 'Salvar Meta';
  document.getElementById('meta-cancel-btn').classList.add('hidden');
}

async function deleteMeta(id) {
  if (!confirm('Deseja realmente excluir esta meta?')) {
    return;
  }
  
  try {
    await axios.delete(`${API_URL}/api/metas/${id}`);
    showNotification('Meta excluída com sucesso!', 'success');
    loadMetas();
  } catch (error) {
    console.error('Erro ao excluir meta:', error);
    showNotification('Erro ao excluir meta', 'error');
  }
}

// ===========================
// CADASTROS (DESIGNERS E PRODUTOS)
// ===========================

async function loadCadastros() {
  await loadDesignersAndProdutos();
  renderDesignersList();
  renderProdutosList();
}

function renderDesignersList() {
  const container = document.getElementById('listaDesigners');
  
  container.innerHTML = designers.map(d => `
    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition">
      <span class="font-medium text-gray-800">
        <i class="fas fa-user-circle text-blue-600 mr-2"></i>
        ${d.nome}
      </span>
      <button onclick="deleteDesigner(${d.id})" class="text-red-600 hover:text-red-800">
        <i class="fas fa-trash"></i>
      </button>
    </div>
  `).join('');
}

function renderProdutosList() {
  const container = document.getElementById('listaProdutos');
  
  container.innerHTML = produtos.map(p => `
    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition">
      <span class="font-medium text-gray-800">
        <i class="fas fa-box text-green-600 mr-2"></i>
        ${p.nome}
      </span>
      <button onclick="deleteProduto(${p.id})" class="text-red-600 hover:text-red-800">
        <i class="fas fa-trash"></i>
      </button>
    </div>
  `).join('');
}

async function deleteDesigner(id) {
  if (!confirm('Deseja realmente remover este designer? Os lançamentos associados não serão excluídos.')) {
    return;
  }
  
  try {
    await axios.delete(`${API_URL}/api/designers/${id}`);
    showNotification('Designer removido com sucesso!', 'success');
    loadCadastros();
  } catch (error) {
    console.error('Erro ao remover designer:', error);
    showNotification('Erro ao remover designer', 'error');
  }
}

async function deleteProduto(id) {
  if (!confirm('Deseja realmente remover este produto? Os lançamentos associados não serão excluídos.')) {
    return;
  }
  
  try {
    await axios.delete(`${API_URL}/api/produtos/${id}`);
    showNotification('Produto removido com sucesso!', 'success');
    loadCadastros();
  } catch (error) {
    console.error('Erro ao remover produto:', error);
    showNotification('Erro ao remover produto', 'error');
  }
}

// ===========================
// FORMULÁRIOS
// ===========================

document.addEventListener('DOMContentLoaded', () => {
  // Formulário de lançamento
  const formLancamento = document.getElementById('formLancamento');
  if (formLancamento) {
    formLancamento.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const data = {
        designer_id: parseInt(document.getElementById('input-designer').value),
        produto_id: parseInt(document.getElementById('input-produto').value),
        semana: parseInt(document.getElementById('input-semana').value),
        data: document.getElementById('input-data').value,
        quantidade_criada: parseInt(document.getElementById('input-criada').value),
        quantidade_aprovada: parseInt(document.getElementById('input-aprovada').value),
        observacoes: document.getElementById('input-obs').value
      };
      
      try {
        await axios.post(`${API_URL}/api/lancamentos`, data);
        showNotification('Lançamento cadastrado com sucesso!', 'success');
        formLancamento.reset();
        document.getElementById('input-data').valueAsDate = new Date();
        loadLancamentos(currentPage);
      } catch (error) {
        console.error('Erro ao cadastrar lançamento:', error);
        showNotification('Erro ao cadastrar lançamento', 'error');
      }
    });
  }
  
  // Formulário de edição de lançamento
  const formEditLancamento = document.getElementById('formEditLancamento');
  if (formEditLancamento) {
    formEditLancamento.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const id = document.getElementById('edit-id').value;
      const data = {
        designer_id: parseInt(document.getElementById('edit-designer').value),
        produto_id: parseInt(document.getElementById('edit-produto').value),
        semana: parseInt(document.getElementById('edit-semana').value),
        data: document.getElementById('edit-data').value,
        quantidade_criada: parseInt(document.getElementById('edit-criada').value),
        quantidade_aprovada: parseInt(document.getElementById('edit-aprovada').value),
        observacoes: document.getElementById('edit-obs').value
      };
      
      try {
        await axios.put(`${API_URL}/api/lancamentos/${id}`, data);
        showNotification('Lançamento atualizado com sucesso!', 'success');
        closeEditModal();
        loadLancamentos(currentPage);
      } catch (error) {
        console.error('Erro ao atualizar lançamento:', error);
        showNotification('Erro ao atualizar lançamento', 'error');
      }
    });
  }
  
  // Formulário de meta
  const formMeta = document.getElementById('formMeta');
  if (formMeta) {
    formMeta.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const id = document.getElementById('meta-id').value;
      const data = {
        produto_id: parseInt(document.getElementById('meta-produto').value),
        meta_aprovacao: parseInt(document.getElementById('meta-aprovacao').value),
        periodo_semanas: parseInt(document.getElementById('meta-periodo').value)
      };
      
      try {
        if (id) {
          await axios.put(`${API_URL}/api/metas/${id}`, data);
          showNotification('Meta atualizada com sucesso!', 'success');
        } else {
          await axios.post(`${API_URL}/api/metas`, data);
          showNotification('Meta cadastrada com sucesso!', 'success');
        }
        formMeta.reset();
        cancelEditMeta();
        loadMetas();
      } catch (error) {
        console.error('Erro ao salvar meta:', error);
        showNotification('Erro ao salvar meta', 'error');
      }
    });
  }
  
  // Formulário de designer
  const formDesigner = document.getElementById('formDesigner');
  if (formDesigner) {
    formDesigner.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const nome = document.getElementById('input-designer-nome').value;
      
      try {
        await axios.post(`${API_URL}/api/designers`, { nome });
        showNotification('Designer cadastrado com sucesso!', 'success');
        formDesigner.reset();
        loadCadastros();
      } catch (error) {
        console.error('Erro ao cadastrar designer:', error);
        showNotification('Erro ao cadastrar designer', 'error');
      }
    });
  }
  
  // Formulário de produto
  const formProduto = document.getElementById('formProduto');
  if (formProduto) {
    formProduto.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const nome = document.getElementById('input-produto-nome').value;
      
      try {
        await axios.post(`${API_URL}/api/produtos`, { nome });
        showNotification('Produto cadastrado com sucesso!', 'success');
        formProduto.reset();
        loadCadastros();
      } catch (error) {
        console.error('Erro ao cadastrar produto:', error);
        showNotification('Erro ao cadastrar produto', 'error');
      }
    });
  }
  
  // Inicializar aplicação
  initializeApp();
});

// ===========================
// NOTIFICAÇÕES
// ===========================

function showNotification(message, type = 'info') {
  const colors = {
    success: 'bg-green-500',
    error: 'bg-red-500',
    info: 'bg-blue-500'
  };
  
  const notification = document.createElement('div');
  notification.className = `fixed top-4 right-4 ${colors[type]} text-white px-6 py-3 rounded-lg shadow-lg z-50 transition-opacity`;
  notification.textContent = message;
  
  document.body.appendChild(notification);
  
  setTimeout(() => {
    notification.style.opacity = '0';
    setTimeout(() => notification.remove(), 300);
  }, 3000);
}

// ===========================
// TAB DESIGNERS
// ===========================

async function loadDesignersList() {
  const container = document.getElementById('designersList');
  
  if (!designers || designers.length === 0) {
    await loadDesignersAndProdutos();
  }
  
  // Carregar estatísticas gerais
  try {
    const statsRes = await axios.get(`${API_URL}/api/relatorios/estatisticas`);
    const stats = statsRes.data;
    
    document.getElementById('designers-stat-total').textContent = stats.total_designers || 0;
    document.getElementById('designers-stat-lancamentos').textContent = stats.total_lancamentos || 0;
    document.getElementById('designers-stat-aprovados').textContent = stats.total_aprovadas || 0;
    document.getElementById('designers-stat-taxa').textContent = (stats.taxa_aprovacao_geral || 0) + '%';
  } catch (error) {
    console.error('Erro ao carregar estatísticas:', error);
  }
  
  // Buscar estatísticas individuais de cada designer
  const designersWithStats = await Promise.all(designers.map(async (designer) => {
    try {
      const statsRes = await axios.get(`${API_URL}/api/designer/${designer.id}/stats`);
      return {
        ...designer,
        stats: statsRes.data
      };
    } catch (error) {
      return {
        ...designer,
        stats: null
      };
    }
  }));
  
  container.innerHTML = designersWithStats.map(designer => {
    const stats = designer.stats;
    const totalTarefas = stats?.total_tarefas || 0;
    const aprovadas = stats?.aprovadas_ok || 0;
    const taxaConclusao = totalTarefas > 0 ? Math.round((aprovadas / totalTarefas) * 100) : 0;
    
    return `
      <a href="/designer/${designer.id}" 
         class="block p-6 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl hover:shadow-lg transition border border-blue-200 hover:border-blue-400">
        <div class="flex items-center space-x-4 mb-4">
          <div class="bg-blue-600 text-white w-14 h-14 rounded-full flex items-center justify-center text-2xl font-bold">
            ${designer.nome.charAt(0).toUpperCase()}
          </div>
          <div class="flex-1">
            <h3 class="text-lg font-bold text-gray-800">${designer.nome}</h3>
            <p class="text-sm text-gray-600">
              <i class="fas fa-clipboard-check mr-1"></i>
              Planilha de Controle
            </p>
          </div>
          <div>
            <i class="fas fa-arrow-right text-blue-600 text-xl"></i>
          </div>
        </div>
        ${stats ? `
        <div class="grid grid-cols-3 gap-2 pt-4 border-t border-blue-200">
          <div class="text-center">
            <div class="text-xs text-gray-500">Tarefas</div>
            <div class="text-lg font-bold text-gray-800">${totalTarefas}</div>
          </div>
          <div class="text-center">
            <div class="text-xs text-gray-500">OK</div>
            <div class="text-lg font-bold text-green-600">${aprovadas}</div>
          </div>
          <div class="text-center">
            <div class="text-xs text-gray-500">Taxa</div>
            <div class="text-lg font-bold text-purple-600">${taxaConclusao}%</div>
          </div>
        </div>
        ` : ''}
      </a>
    `;
  }).join('');
}
