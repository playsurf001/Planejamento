import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { serveStatic } from 'hono/cloudflare-workers'

type Bindings = {
  DB: D1Database;
}

const app = new Hono<{ Bindings: Bindings }>()

// Enable CORS for API routes
app.use('/api/*', cors())

// Serve static files
app.use('/static/*', serveStatic({ root: './public' }))

// ======================
// API ROUTES - DESIGNERS
// ======================

app.get('/api/designers', async (c) => {
  const { DB } = c.env
  const result = await DB.prepare('SELECT * FROM designers WHERE ativo = 1 ORDER BY nome').all()
  return c.json(result.results)
})

app.post('/api/designers', async (c) => {
  const { DB } = c.env
  const { nome } = await c.req.json()
  
  const result = await DB.prepare('INSERT INTO designers (nome) VALUES (?) RETURNING *')
    .bind(nome)
    .first()
  
  return c.json(result, 201)
})

app.delete('/api/designers/:id', async (c) => {
  const { DB } = c.env
  const id = c.req.param('id')
  
  await DB.prepare('UPDATE designers SET ativo = 0 WHERE id = ?').bind(id).run()
  return c.json({ success: true })
})

// ======================
// API ROUTES - PRODUTOS
// ======================

app.get('/api/produtos', async (c) => {
  const { DB } = c.env
  const result = await DB.prepare('SELECT * FROM produtos WHERE ativo = 1 ORDER BY nome').all()
  return c.json(result.results)
})

app.post('/api/produtos', async (c) => {
  const { DB } = c.env
  const { nome } = await c.req.json()
  
  const result = await DB.prepare('INSERT INTO produtos (nome) VALUES (?) RETURNING *')
    .bind(nome)
    .first()
  
  return c.json(result, 201)
})

app.delete('/api/produtos/:id', async (c) => {
  const { DB } = c.env
  const id = c.req.param('id')
  
  await DB.prepare('UPDATE produtos SET ativo = 0 WHERE id = ?').bind(id).run()
  return c.json({ success: true })
})

// ======================
// API ROUTES - METAS
// ======================

app.get('/api/metas', async (c) => {
  const { DB } = c.env
  const result = await DB.prepare(`
    SELECT m.id, m.produto_id, p.nome as produto_nome, m.meta_aprovacao, m.periodo_semanas
    FROM metas m
    JOIN produtos p ON m.produto_id = p.id
    ORDER BY p.nome
  `).all()
  return c.json(result.results)
})

app.post('/api/metas', async (c) => {
  const { DB } = c.env
  const { produto_id, meta_aprovacao, periodo_semanas } = await c.req.json()
  
  const result = await DB.prepare(`
    INSERT INTO metas (produto_id, meta_aprovacao, periodo_semanas) 
    VALUES (?, ?, ?) 
    RETURNING *
  `)
    .bind(produto_id, meta_aprovacao, periodo_semanas || 18)
    .first()
  
  return c.json(result, 201)
})

app.put('/api/metas/:id', async (c) => {
  const { DB } = c.env
  const id = c.req.param('id')
  const { meta_aprovacao, periodo_semanas } = await c.req.json()
  
  await DB.prepare(`
    UPDATE metas 
    SET meta_aprovacao = ?, periodo_semanas = ?
    WHERE id = ?
  `)
    .bind(meta_aprovacao, periodo_semanas, id)
    .run()
  
  const result = await DB.prepare('SELECT * FROM metas WHERE id = ?').bind(id).first()
  return c.json(result)
})

app.delete('/api/metas/:id', async (c) => {
  const { DB } = c.env
  const id = c.req.param('id')
  
  await DB.prepare('DELETE FROM metas WHERE id = ?').bind(id).run()
  return c.json({ success: true })
})

// ======================
// API ROUTES - LANÇAMENTOS
// ======================

app.get('/api/lancamentos', async (c) => {
  const { DB } = c.env
  const { designer_id, produto_id, semana, mes, ano, limit = 100, offset = 0 } = c.req.query()
  
  let query = `
    SELECT 
      l.id, l.semana, l.data, l.quantidade_criada, l.quantidade_aprovada, l.observacoes,
      d.nome as designer_nome, d.id as designer_id,
      p.nome as produto_nome, p.id as produto_id,
      strftime('%m', l.data) as mes,
      strftime('%Y', l.data) as ano
    FROM lancamentos l
    JOIN designers d ON l.designer_id = d.id
    JOIN produtos p ON l.produto_id = p.id
    WHERE 1=1
  `
  const params: any[] = []
  
  if (designer_id) {
    query += ' AND l.designer_id = ?'
    params.push(designer_id)
  }
  
  if (produto_id) {
    query += ' AND l.produto_id = ?'
    params.push(produto_id)
  }
  
  if (semana) {
    query += ' AND l.semana = ?'
    params.push(semana)
  }
  
  if (mes) {
    query += ' AND strftime("%m", l.data) = ?'
    params.push(mes.toString().padStart(2, '0'))
  }
  
  if (ano) {
    query += ' AND strftime("%Y", l.data) = ?'
    params.push(ano)
  }
  
  query += ' ORDER BY l.data DESC, l.semana DESC LIMIT ? OFFSET ?'
  params.push(limit, offset)
  
  const result = await DB.prepare(query).bind(...params).all()
  
  // Count total
  let countQuery = `
    SELECT COUNT(*) as total
    FROM lancamentos l
    WHERE 1=1
  `
  const countParams: any[] = []
  
  if (designer_id) {
    countQuery += ' AND l.designer_id = ?'
    countParams.push(designer_id)
  }
  
  if (produto_id) {
    countQuery += ' AND l.produto_id = ?'
    countParams.push(produto_id)
  }
  
  if (semana) {
    countQuery += ' AND l.semana = ?'
    countParams.push(semana)
  }
  
  if (mes) {
    countQuery += ' AND strftime("%m", l.data) = ?'
    countParams.push(mes.toString().padStart(2, '0'))
  }
  
  if (ano) {
    countQuery += ' AND strftime("%Y", l.data) = ?'
    countParams.push(ano)
  }
  
  const countResult = await DB.prepare(countQuery).bind(...countParams).first()
  
  return c.json({
    data: result.results,
    total: countResult?.total || 0,
    limit: parseInt(limit),
    offset: parseInt(offset)
  })
})

app.get('/api/lancamentos/:id', async (c) => {
  const { DB } = c.env
  const id = c.req.param('id')
  
  const result = await DB.prepare(`
    SELECT 
      l.id, l.semana, l.data, l.quantidade_criada, l.quantidade_aprovada, l.observacoes,
      l.designer_id, l.produto_id,
      d.nome as designer_nome,
      p.nome as produto_nome
    FROM lancamentos l
    JOIN designers d ON l.designer_id = d.id
    JOIN produtos p ON l.produto_id = p.id
    WHERE l.id = ?
  `).bind(id).first()
  
  return c.json(result)
})

app.post('/api/lancamentos', async (c) => {
  const { DB } = c.env
  const { 
    designer_id, produto_id, semana, data, 
    quantidade_criada, quantidade_aprovada, observacoes,
    criado_check, aprovado_ok, posicao, status 
  } = await c.req.json()
  
  // Calcular status automaticamente se não fornecido
  let finalStatus = status;
  if (!finalStatus) {
    const criado = criado_check || (quantidade_criada > 0 ? 1 : 0);
    const aprovado = aprovado_ok || (quantidade_aprovada > 0 ? 1 : 0);
    
    if (criado && aprovado) {
      finalStatus = 'completo';
    } else if (criado || aprovado) {
      finalStatus = 'em_andamento';
    } else {
      finalStatus = 'pendente';
    }
  }
  
  const result = await DB.prepare(`
    INSERT INTO lancamentos (
      designer_id, produto_id, semana, data, 
      quantidade_criada, quantidade_aprovada, observacoes,
      criado_check, aprovado_ok, posicao, status
    ) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) 
    RETURNING *
  `)
    .bind(
      designer_id, produto_id, semana, data, 
      quantidade_criada || 0, quantidade_aprovada || 0, observacoes || null,
      criado_check || 0, aprovado_ok || 0, posicao || null, finalStatus
    )
    .first()
  
  return c.json(result, 201)
})

app.put('/api/lancamentos/:id', async (c) => {
  const { DB } = c.env
  const id = c.req.param('id')
  const { 
    designer_id, produto_id, semana, data, 
    quantidade_criada, quantidade_aprovada, observacoes,
    criado_check, aprovado_ok, posicao, status 
  } = await c.req.json()
  
  // Calcular status automaticamente se não fornecido
  let finalStatus = status;
  if (!finalStatus) {
    const criado = criado_check !== undefined ? criado_check : (quantidade_criada > 0 ? 1 : 0);
    const aprovado = aprovado_ok !== undefined ? aprovado_ok : (quantidade_aprovada > 0 ? 1 : 0);
    
    if (criado && aprovado) {
      finalStatus = 'completo';
    } else if (criado || aprovado) {
      finalStatus = 'em_andamento';
    } else {
      finalStatus = 'pendente';
    }
  }
  
  await DB.prepare(`
    UPDATE lancamentos 
    SET designer_id = ?, produto_id = ?, semana = ?, data = ?, 
        quantidade_criada = ?, quantidade_aprovada = ?, observacoes = ?, 
        criado_check = ?,
        aprovado_ok = ?,
        posicao = ?,
        status = ?,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `)
    .bind(
      designer_id, produto_id, semana, data, 
      quantidade_criada, quantidade_aprovada, observacoes || null,
      criado_check !== undefined ? criado_check : 0, 
      aprovado_ok !== undefined ? aprovado_ok : 0, 
      posicao || null, 
      finalStatus, id
    )
    .run()
  
  const result = await DB.prepare('SELECT * FROM lancamentos WHERE id = ?').bind(id).first()
  return c.json(result)
})

app.delete('/api/lancamentos/:id', async (c) => {
  const { DB } = c.env
  const id = c.req.param('id')
  
  await DB.prepare('DELETE FROM lancamentos WHERE id = ?').bind(id).run()
  return c.json({ success: true })
})

// ======================
// API ROUTES - CHECKLIST DESIGNER (NOVAS)
// ======================

// Obter checklist de um designer específico (tela individual)
app.get('/api/designer/:designer_id/checklist', async (c) => {
  const { DB } = c.env
  const designer_id = c.req.param('designer_id')
  const { semana } = c.req.query()
  
  let query = `
    SELECT 
      l.id, l.semana, l.data, l.quantidade_criada, l.quantidade_aprovada, 
      l.criado_check, l.aprovado_ok, l.posicao, l.status, l.observacoes,
      p.nome as produto_nome, p.id as produto_id,
      d.nome as designer_nome
    FROM lancamentos l
    JOIN produtos p ON l.produto_id = p.id
    JOIN designers d ON l.designer_id = d.id
    WHERE l.designer_id = ?
  `
  const params: any[] = [designer_id]
  
  if (semana) {
    query += ' AND l.semana = ?'
    params.push(semana)
  }
  
  query += ' ORDER BY l.semana DESC, p.nome'
  
  const result = await DB.prepare(query).bind(...params).all()
  return c.json(result.results)
})

// Marcar/desmarcar criação (checkbox)
app.patch('/api/lancamentos/:id/check-criado', async (c) => {
  const { DB } = c.env
  const id = c.req.param('id')
  const { checked } = await c.req.json()
  
  await DB.prepare(`
    UPDATE lancamentos 
    SET criado_check = ?,
        status = CASE WHEN ? = 1 AND aprovado_ok = 1 THEN 'completo' ELSE 'em_andamento' END,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `)
    .bind(checked ? 1 : 0, checked ? 1 : 0, id)
    .run()
  
  const result = await DB.prepare('SELECT * FROM lancamentos WHERE id = ?').bind(id).first()
  return c.json(result)
})

// Marcar/desmarcar aprovação (OK)
app.patch('/api/lancamentos/:id/check-aprovado', async (c) => {
  const { DB } = c.env
  const id = c.req.param('id')
  const { checked, quantidade_aprovada } = await c.req.json()
  
  await DB.prepare(`
    UPDATE lancamentos 
    SET aprovado_ok = ?,
        quantidade_aprovada = ?,
        status = CASE WHEN criado_check = 1 AND ? = 1 THEN 'completo' 
                     WHEN ? = 1 THEN 'em_andamento'
                     ELSE 'pendente' END,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `)
    .bind(checked ? 1 : 0, quantidade_aprovada || 0, checked ? 1 : 0, checked ? 1 : 0, id)
    .run()
  
  const result = await DB.prepare('SELECT * FROM lancamentos WHERE id = ?').bind(id).first()
  return c.json(result)
})

// Atualizar posição/ranking
app.patch('/api/lancamentos/:id/posicao', async (c) => {
  const { DB } = c.env
  const id = c.req.param('id')
  const { posicao } = await c.req.json()
  
  await DB.prepare(`
    UPDATE lancamentos 
    SET posicao = ?,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `)
    .bind(posicao, id)
    .run()
  
  const result = await DB.prepare('SELECT * FROM lancamentos WHERE id = ?').bind(id).first()
  return c.json(result)
})

// Estatísticas do designer (para a tela individual)
app.get('/api/designer/:designer_id/stats', async (c) => {
  const { DB } = c.env
  const designer_id = c.req.param('designer_id')
  const { semana } = c.req.query()
  
  let query = `
    SELECT 
      COUNT(*) as total_tarefas,
      SUM(CASE WHEN criado_check = 1 THEN 1 ELSE 0 END) as criadas_ok,
      SUM(CASE WHEN aprovado_ok = 1 THEN 1 ELSE 0 END) as aprovadas_ok,
      SUM(CASE WHEN status = 'completo' THEN 1 ELSE 0 END) as completas,
      SUM(quantidade_criada) as total_criadas,
      SUM(quantidade_aprovada) as total_aprovadas
    FROM lancamentos
    WHERE designer_id = ?
  `
  const params: any[] = [designer_id]
  
  if (semana) {
    query += ' AND semana = ?'
    params.push(semana)
  }
  
  const stats = await DB.prepare(query).bind(...params).first()
  return c.json(stats)
})


// ======================
// API ROUTES - RELATÓRIOS E DASHBOARD
// ======================

// Resumo por designer
app.get('/api/relatorios/por-designer', async (c) => {
  const { DB } = c.env
  const { semana_inicio, semana_fim, mes, ano } = c.req.query()
  
  let query = `
    SELECT 
      d.nome as designer,
      d.id as designer_id,
      COUNT(l.id) as total_lancamentos,
      SUM(l.quantidade_criada) as total_criadas,
      SUM(l.quantidade_aprovada) as total_aprovadas,
      ROUND(CAST(SUM(l.quantidade_aprovada) AS FLOAT) / NULLIF(SUM(l.quantidade_criada), 0) * 100, 2) as taxa_aprovacao
    FROM designers d
    LEFT JOIN lancamentos l ON d.id = l.designer_id
    WHERE d.ativo = 1
  `
  const params: any[] = []
  
  if (semana_inicio) {
    query += ' AND l.semana >= ?'
    params.push(semana_inicio)
  }
  
  if (semana_fim) {
    query += ' AND l.semana <= ?'
    params.push(semana_fim)
  }
  
  if (mes) {
    query += ' AND strftime("%m", l.data) = ?'
    params.push(mes.toString().padStart(2, '0'))
  }
  
  if (ano) {
    query += ' AND strftime("%Y", l.data) = ?'
    params.push(ano)
  }
  
  query += ' GROUP BY d.id, d.nome ORDER BY total_aprovadas DESC'
  
  const result = await DB.prepare(query).bind(...params).all()
  return c.json(result.results)
})

// Resumo por produto
app.get('/api/relatorios/por-produto', async (c) => {
  const { DB } = c.env
  const { semana_inicio, semana_fim, mes, ano, limit } = c.req.query()
  
  let query = `
    SELECT 
      p.nome as produto,
      p.id as produto_id,
      m.meta_aprovacao,
      COUNT(l.id) as total_lancamentos,
      SUM(l.quantidade_criada) as total_criadas,
      SUM(l.quantidade_aprovada) as total_aprovadas,
      ROUND(CAST(SUM(l.quantidade_aprovada) AS FLOAT) / NULLIF(SUM(l.quantidade_criada), 0) * 100, 2) as taxa_aprovacao,
      ROUND(CAST(SUM(l.quantidade_aprovada) AS FLOAT) / NULLIF(m.meta_aprovacao, 0) * 100, 2) as progresso_meta,
      MAX(l.data) as ultima_atualizacao
    FROM produtos p
    LEFT JOIN lancamentos l ON p.id = l.produto_id
    LEFT JOIN metas m ON p.id = m.produto_id
    WHERE p.ativo = 1
  `
  const params: any[] = []
  
  if (semana_inicio) {
    query += ' AND l.semana >= ?'
    params.push(semana_inicio)
  }
  
  if (semana_fim) {
    query += ' AND l.semana <= ?'
    params.push(semana_fim)
  }
  
  if (mes) {
    query += ' AND strftime("%m", l.data) = ?'
    params.push(mes.toString().padStart(2, '0'))
  }
  
  if (ano) {
    query += ' AND strftime("%Y", l.data) = ?'
    params.push(ano)
  }
  
  query += ' GROUP BY p.id, p.nome, m.meta_aprovacao ORDER BY ultima_atualizacao DESC, total_aprovadas DESC'
  
  if (limit) {
    query += ' LIMIT ?'
    params.push(limit)
  }
  
  const result = await DB.prepare(query).bind(...params).all()
  return c.json(result.results)
})

// Estatísticas gerais
app.get('/api/relatorios/estatisticas', async (c) => {
  const { DB } = c.env
  const { mes, ano } = c.req.query()
  
  let query = `
    SELECT 
      COUNT(DISTINCT designer_id) as total_designers,
      COUNT(DISTINCT produto_id) as total_produtos,
      COUNT(*) as total_lancamentos,
      SUM(quantidade_criada) as total_criadas,
      SUM(quantidade_aprovada) as total_aprovadas,
      ROUND(CAST(SUM(quantidade_aprovada) AS FLOAT) / NULLIF(SUM(quantidade_criada), 0) * 100, 2) as taxa_aprovacao_geral
    FROM lancamentos
    WHERE 1=1
  `
  const params: any[] = []
  
  if (mes) {
    query += ' AND strftime("%m", data) = ?'
    params.push(mes.toString().padStart(2, '0'))
  }
  
  if (ano) {
    query += ' AND strftime("%Y", data) = ?'
    params.push(ano)
  }
  
  const stats = await DB.prepare(query).bind(...params).first()
  
  return c.json(stats)
})

// Timeline de produção
app.get('/api/relatorios/timeline', async (c) => {
  const { DB } = c.env
  const { limit = 12, mes, ano } = c.req.query()
  
  let query = `
    SELECT 
      semana,
      strftime('%m', data) as mes,
      strftime('%Y', data) as ano,
      COUNT(*) as total_lancamentos,
      SUM(quantidade_criada) as total_criadas,
      SUM(quantidade_aprovada) as total_aprovadas,
      ROUND(CAST(SUM(quantidade_aprovada) AS FLOAT) / NULLIF(SUM(quantidade_criada), 0) * 100, 2) as taxa_aprovacao
    FROM lancamentos
    WHERE 1=1
  `
  const params: any[] = []
  
  if (mes) {
    query += ' AND strftime("%m", data) = ?'
    params.push(mes.toString().padStart(2, '0'))
  }
  
  if (ano) {
    query += ' AND strftime("%Y", data) = ?'
    params.push(ano)
  }
  
  query += ' GROUP BY semana, mes, ano ORDER BY ano DESC, semana DESC LIMIT ?'
  params.push(limit)
  
  const result = await DB.prepare(query).bind(...params).all()
  
  return c.json(result.results)
})

// Listar períodos disponíveis (meses/anos)
app.get('/api/periodos', async (c) => {
  const { DB } = c.env
  
  const result = await DB.prepare(`
    SELECT DISTINCT 
      strftime('%Y', data) as ano,
      strftime('%m', data) as mes,
      strftime('%Y-%m', data) as periodo
    FROM lancamentos
    ORDER BY ano DESC, mes DESC
  `).all()
  
  return c.json(result.results)
})

// ======================
// PÁGINA PRINCIPAL
// ======================

app.get('/', (c) => {
  return c.html(`
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Controle de Produção - Sistema Profissional</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    </head>
    <body class="bg-gray-50">
        <!-- Header -->
        <header class="bg-gradient-to-r from-blue-600 to-blue-800 text-white shadow-lg">
            <div class="container mx-auto px-6 py-4">
                <div class="flex items-center justify-between">
                    <div class="flex items-center space-x-3">
                        <i class="fas fa-chart-line text-3xl"></i>
                        <div>
                            <h1 class="text-2xl font-bold">Controle de Produção</h1>
                            <p class="text-blue-200 text-sm">Sistema de Gestão de Design e Lançamentos</p>
                        </div>
                    </div>
                    <div class="flex space-x-2">
                        <button onclick="showTab('dashboard')" class="tab-btn px-4 py-2 rounded-lg bg-white/20 hover:bg-white/30 transition">
                            <i class="fas fa-chart-pie mr-2"></i>Dashboard
                        </button>
                        <button onclick="showTab('designers')" class="tab-btn px-4 py-2 rounded-lg bg-white/20 hover:bg-white/30 transition">
                            <i class="fas fa-user-check mr-2"></i>Designers
                        </button>
                        <button onclick="showTab('lancamentos')" class="tab-btn px-4 py-2 rounded-lg bg-white/20 hover:bg-white/30 transition">
                            <i class="fas fa-plus-circle mr-2"></i>Lançamentos
                        </button>
                        <button onclick="showTab('relatorios')" class="tab-btn px-4 py-2 rounded-lg bg-white/20 hover:bg-white/30 transition">
                            <i class="fas fa-file-chart-line mr-2"></i>Relatórios
                        </button>
                        <button onclick="showTab('metas')" class="tab-btn px-4 py-2 rounded-lg bg-white/20 hover:bg-white/30 transition">
                            <i class="fas fa-bullseye mr-2"></i>Metas
                        </button>
                        <button onclick="showTab('cadastros')" class="tab-btn px-4 py-2 rounded-lg bg-white/20 hover:bg-white/30 transition">
                            <i class="fas fa-cog mr-2"></i>Cadastros
                        </button>
                    </div>
                </div>
            </div>
        </header>

        <main class="container mx-auto px-6 py-8">
            <!-- Dashboard Tab -->
            <div id="tab-dashboard" class="tab-content">
                <!-- Filtros -->
                <div class="bg-white rounded-xl shadow-md p-4 mb-6">
                    <div class="flex items-center space-x-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Mês</label>
                            <select id="filter-mes" onchange="applyDashboardFilters()" class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                                <option value="">Todos</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Ano</label>
                            <select id="filter-ano" onchange="applyDashboardFilters()" class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                                <option value="">Todos</option>
                            </select>
                        </div>
                        <button onclick="clearDashboardFilters()" class="mt-6 px-4 py-2 bg-gray-500 hover:bg-gray-600 text-white rounded-lg transition">
                            <i class="fas fa-times mr-2"></i>Limpar
                        </button>
                    </div>
                </div>

                <!-- Estatísticas Gerais -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <div class="bg-white rounded-xl shadow-md p-6 border-l-4 border-blue-500">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-gray-500 text-sm font-medium">Total de Designers</p>
                                <p id="stat-designers" class="text-3xl font-bold text-gray-800 mt-2">-</p>
                            </div>
                            <div class="bg-blue-100 rounded-full p-3">
                                <i class="fas fa-users text-blue-600 text-2xl"></i>
                            </div>
                        </div>
                    </div>
                    
                    <div class="bg-white rounded-xl shadow-md p-6 border-l-4 border-green-500">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-gray-500 text-sm font-medium">Total Aprovadas</p>
                                <p id="stat-aprovadas" class="text-3xl font-bold text-gray-800 mt-2">-</p>
                            </div>
                            <div class="bg-green-100 rounded-full p-3">
                                <i class="fas fa-check-circle text-green-600 text-2xl"></i>
                            </div>
                        </div>
                    </div>
                    
                    <div class="bg-white rounded-xl shadow-md p-6 border-l-4 border-yellow-500">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-gray-500 text-sm font-medium">Total Criadas</p>
                                <p id="stat-criadas" class="text-3xl font-bold text-gray-800 mt-2">-</p>
                            </div>
                            <div class="bg-yellow-100 rounded-full p-3">
                                <i class="fas fa-palette text-yellow-600 text-2xl"></i>
                            </div>
                        </div>
                    </div>
                    
                    <div class="bg-white rounded-xl shadow-md p-6 border-l-4 border-purple-500">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-gray-500 text-sm font-medium">Taxa de Aprovação</p>
                                <p id="stat-taxa" class="text-3xl font-bold text-gray-800 mt-2">-%</p>
                            </div>
                            <div class="bg-purple-100 rounded-full p-3">
                                <i class="fas fa-percentage text-purple-600 text-2xl"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Gráficos -->
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                    <div class="bg-white rounded-xl shadow-md p-6">
                        <h3 class="text-lg font-semibold text-gray-800 mb-4">
                            <i class="fas fa-chart-bar text-blue-600 mr-2"></i>
                            Performance por Designer
                        </h3>
                        <div style="height: 300px; position: relative;">
                            <canvas id="chartDesigners"></canvas>
                        </div>
                    </div>
                    
                    <div class="bg-white rounded-xl shadow-md p-6">
                        <h3 class="text-lg font-semibold text-gray-800 mb-4">
                            <i class="fas fa-chart-line text-green-600 mr-2"></i>
                            Timeline de Produção
                        </h3>
                        <div style="height: 300px; position: relative;">
                            <canvas id="chartTimeline"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Top Produtos -->
                <div class="bg-white rounded-xl shadow-md p-6">
                    <h3 class="text-lg font-semibold text-gray-800 mb-4">
                        <i class="fas fa-trophy text-yellow-600 mr-2"></i>
                        Top 6 Produtos Mais Recentes
                    </h3>
                    <div id="topProdutos" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        <!-- Será preenchido via JS -->
                    </div>
                </div>
            </div>

            <!-- Designers Tab -->
            <div id="tab-designers" class="tab-content hidden">
                <!-- Estatísticas Gerais dos Designers -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
                    <div class="bg-white rounded-xl shadow-md p-6 border-l-4 border-blue-500">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-gray-500 text-sm font-medium">Total Designers</p>
                                <p id="designers-stat-total" class="text-3xl font-bold text-gray-800 mt-2">0</p>
                            </div>
                            <div class="bg-blue-100 rounded-full p-3">
                                <i class="fas fa-users text-blue-600 text-2xl"></i>
                            </div>
                        </div>
                    </div>
                    
                    <div class="bg-white rounded-xl shadow-md p-6 border-l-4 border-green-500">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-gray-500 text-sm font-medium">Total Lançamentos</p>
                                <p id="designers-stat-lancamentos" class="text-3xl font-bold text-gray-800 mt-2">0</p>
                            </div>
                            <div class="bg-green-100 rounded-full p-3">
                                <i class="fas fa-clipboard-list text-green-600 text-2xl"></i>
                            </div>
                        </div>
                    </div>
                    
                    <div class="bg-white rounded-xl shadow-md p-6 border-l-4 border-yellow-500">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-gray-500 text-sm font-medium">Total Aprovados</p>
                                <p id="designers-stat-aprovados" class="text-3xl font-bold text-gray-800 mt-2">0</p>
                            </div>
                            <div class="bg-yellow-100 rounded-full p-3">
                                <i class="fas fa-check-circle text-yellow-600 text-2xl"></i>
                            </div>
                        </div>
                    </div>
                    
                    <div class="bg-white rounded-xl shadow-md p-6 border-l-4 border-purple-500">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-gray-500 text-sm font-medium">Taxa Aprovação</p>
                                <p id="designers-stat-taxa" class="text-3xl font-bold text-gray-800 mt-2">0%</p>
                            </div>
                            <div class="bg-purple-100 rounded-full p-3">
                                <i class="fas fa-percentage text-purple-600 text-2xl"></i>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl shadow-md p-6">
                    <h2 class="text-2xl font-bold text-gray-800 mb-6">
                        <i class="fas fa-users text-blue-600 mr-3"></i>
                        Telas Individuais dos Designers
                    </h2>
                    <p class="text-gray-600 mb-6">Selecione um designer para acessar sua planilha individual de controle:</p>
                    
                    <div id="designersList" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        <!-- Será preenchido via JS -->
                    </div>
                </div>
            </div>

            <!-- Lançamentos Tab -->
            <div id="tab-lancamentos" class="tab-content hidden">
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <!-- Formulário -->
                    <div class="lg:col-span-1">
                        <div class="bg-white rounded-xl shadow-md p-6">
                            <h3 class="text-xl font-semibold text-gray-800 mb-4">
                                <i class="fas fa-plus-circle text-blue-600 mr-2"></i>
                                Novo Lançamento
                            </h3>
                            <form id="formLancamento" class="space-y-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Designer</label>
                                    <select id="input-designer" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" required>
                                        <option value="">Selecione...</option>
                                    </select>
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Produto</label>
                                    <select id="input-produto" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" required>
                                        <option value="">Selecione...</option>
                                    </select>
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Semana</label>
                                    <input type="number" id="input-semana" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" min="1" required>
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Data</label>
                                    <input type="date" id="input-data" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" required>
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Quantidade Criada</label>
                                    <input type="number" id="input-criada" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" min="0" value="0" required>
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Quantidade Aprovada</label>
                                    <input type="number" id="input-aprovada" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" min="0" value="0" required>
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Observações</label>
                                    <textarea id="input-obs" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" rows="3"></textarea>
                                </div>
                                
                                <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg transition shadow-md">
                                    <i class="fas fa-save mr-2"></i>Salvar Lançamento
                                </button>
                            </form>
                        </div>
                    </div>

                    <!-- Lista de Lançamentos -->
                    <div class="lg:col-span-2">
                        <div class="bg-white rounded-xl shadow-md p-6">
                            <div class="flex items-center justify-between mb-4">
                                <h3 class="text-xl font-semibold text-gray-800">
                                    <i class="fas fa-list text-blue-600 mr-2"></i>
                                    Lançamentos
                                </h3>
                                <div class="flex space-x-2">
                                    <select id="lancamentos-semana-filter" onchange="loadLancamentos()" class="px-4 py-2 border border-gray-300 rounded-lg">
                                        <option value="">Todas Semanas</option>
                                    </select>
                                    <button onclick="loadLancamentos()" class="text-blue-600 hover:text-blue-800">
                                        <i class="fas fa-sync-alt"></i>
                                    </button>
                                </div>
                            </div>
                            <div id="listaLancamentos" class="overflow-x-auto">
                                <!-- Será preenchido via JS -->
                            </div>
                            <div id="paginationLancamentos" class="mt-4 flex justify-center space-x-2">
                                <!-- Paginação será preenchida via JS -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Relatórios Tab -->
            <div id="tab-relatorios" class="tab-content hidden">
                <div class="bg-white rounded-xl shadow-md p-4 mb-6">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center space-x-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Mês</label>
                                <select id="relatorio-mes" onchange="loadRelatorios()" class="px-4 py-2 border border-gray-300 rounded-lg">
                                    <option value="">Todos</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Ano</label>
                                <select id="relatorio-ano" onchange="loadRelatorios()" class="px-4 py-2 border border-gray-300 rounded-lg">
                                    <option value="">Todos</option>
                                </select>
                            </div>
                        </div>
                        <button onclick="generatePDF()" class="px-6 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition shadow-md">
                            <i class="fas fa-file-pdf mr-2"></i>Gerar PDF
                        </button>
                    </div>
                </div>

                <div id="relatorio-content" class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- Relatório por Designer -->
                    <div class="bg-white rounded-xl shadow-md p-6">
                        <h3 class="text-xl font-semibold text-gray-800 mb-4">
                            <i class="fas fa-user-chart text-blue-600 mr-2"></i>
                            Performance por Designer
                        </h3>
                        <div id="relatorioDesigners" class="space-y-4">
                            <!-- Será preenchido via JS -->
                        </div>
                    </div>

                    <!-- Relatório por Produto -->
                    <div class="bg-white rounded-xl shadow-md p-6">
                        <h3 class="text-xl font-semibold text-gray-800 mb-4">
                            <i class="fas fa-box text-green-600 mr-2"></i>
                            Performance por Produto
                        </h3>
                        <div id="relatorioProdutos" class="space-y-4">
                            <!-- Será preenchido via JS -->
                        </div>
                    </div>
                </div>
            </div>

            <!-- Metas Tab -->
            <div id="tab-metas" class="tab-content hidden">
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <!-- Formulário de Meta -->
                    <div class="lg:col-span-1">
                        <div class="bg-white rounded-xl shadow-md p-6">
                            <h3 class="text-xl font-semibold text-gray-800 mb-4">
                                <i class="fas fa-plus-circle text-purple-600 mr-2"></i>
                                <span id="meta-form-title">Nova Meta</span>
                            </h3>
                            <form id="formMeta" class="space-y-4">
                                <input type="hidden" id="meta-id">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Produto</label>
                                    <select id="meta-produto" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500" required>
                                        <option value="">Selecione...</option>
                                    </select>
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Meta de Aprovação</label>
                                    <input type="number" id="meta-aprovacao" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500" min="1" required>
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Período (Semanas)</label>
                                    <input type="number" id="meta-periodo" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500" min="1" value="18" required>
                                </div>
                                
                                <button type="submit" class="w-full bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 px-6 rounded-lg transition shadow-md">
                                    <i class="fas fa-save mr-2"></i>
                                    <span id="meta-btn-text">Salvar Meta</span>
                                </button>
                                
                                <button type="button" onclick="cancelEditMeta()" id="meta-cancel-btn" class="hidden w-full bg-gray-500 hover:bg-gray-600 text-white font-semibold py-2 px-6 rounded-lg transition">
                                    <i class="fas fa-times mr-2"></i>Cancelar
                                </button>
                            </form>
                        </div>
                    </div>

                    <!-- Lista de Metas -->
                    <div class="lg:col-span-2">
                        <div class="bg-white rounded-xl shadow-md p-6">
                            <div class="flex items-center justify-between mb-4">
                                <h3 class="text-xl font-semibold text-gray-800">
                                    <i class="fas fa-bullseye text-purple-600 mr-2"></i>
                                    Metas Cadastradas
                                </h3>
                                <button onclick="loadMetas()" class="text-purple-600 hover:text-purple-800">
                                    <i class="fas fa-sync-alt"></i>
                                </button>
                            </div>
                            <div id="listaMetas" class="overflow-x-auto">
                                <!-- Será preenchido via JS -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Cadastros Tab -->
            <div id="tab-cadastros" class="tab-content hidden">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- Designers -->
                    <div class="bg-white rounded-xl shadow-md p-6">
                        <h3 class="text-xl font-semibold text-gray-800 mb-4">
                            <i class="fas fa-users text-blue-600 mr-2"></i>
                            Designers
                        </h3>
                        <form id="formDesigner" class="mb-4 flex space-x-2">
                            <input type="text" id="input-designer-nome" placeholder="Nome do designer" class="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" required>
                            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition">
                                <i class="fas fa-plus mr-2"></i>Adicionar
                            </button>
                        </form>
                        <div id="listaDesigners" class="space-y-2">
                            <!-- Será preenchido via JS -->
                        </div>
                    </div>

                    <!-- Produtos -->
                    <div class="bg-white rounded-xl shadow-md p-6">
                        <h3 class="text-xl font-semibold text-gray-800 mb-4">
                            <i class="fas fa-box text-green-600 mr-2"></i>
                            Produtos
                        </h3>
                        <form id="formProduto" class="mb-4 flex space-x-2">
                            <input type="text" id="input-produto-nome" placeholder="Nome do produto" class="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500" required>
                            <button type="submit" class="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg transition">
                                <i class="fas fa-plus mr-2"></i>Adicionar
                            </button>
                        </form>
                        <div id="listaProdutos" class="space-y-2">
                            <!-- Será preenchido via JS -->
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <!-- Modal de Edição de Lançamento -->
        <div id="modalEditLancamento" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div class="bg-white rounded-xl shadow-2xl p-6 max-w-md w-full mx-4">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-xl font-semibold text-gray-800">
                        <i class="fas fa-edit text-blue-600 mr-2"></i>
                        Editar Lançamento
                    </h3>
                    <button onclick="closeEditModal()" class="text-gray-500 hover:text-gray-700">
                        <i class="fas fa-times text-xl"></i>
                    </button>
                </div>
                <form id="formEditLancamento" class="space-y-4">
                    <input type="hidden" id="edit-id">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Designer</label>
                        <select id="edit-designer" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" required>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Produto</label>
                        <select id="edit-produto" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" required>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Semana</label>
                        <input type="number" id="edit-semana" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" min="1" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Data</label>
                        <input type="date" id="edit-data" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Quantidade Criada</label>
                        <input type="number" id="edit-criada" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" min="0" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Quantidade Aprovada</label>
                        <input type="number" id="edit-aprovada" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" min="0" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Observações</label>
                        <textarea id="edit-obs" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" rows="2"></textarea>
                    </div>
                    <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg transition shadow-md">
                        <i class="fas fa-save mr-2"></i>Salvar Alterações
                    </button>
                </form>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"></script>
        <script src="/static/app.js"></script>
    </body>
    </html>
  `)
})


// ======================
// PÁGINA DE DESIGNER INDIVIDUAL
// ======================

// Importar a view estilo planilha
import { generateDesignerSheetView } from './designer-sheet-view'

app.get('/designer/:designer_id', async (c) => {
  const { DB } = c.env
  const designer_id = c.req.param('designer_id')
  
  // Buscar designer
  const designer = await DB.prepare('SELECT * FROM designers WHERE id = ? AND ativo = 1').bind(designer_id).first()
  
  if (!designer) {
    return c.text('Designer não encontrado', 404)
  }
  
  // Usar a nova view estilo planilha Excel
  return c.html(generateDesignerSheetView(designer, designer_id))
  
  /* View anterior - Mantida para referência
  return c.html(`
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>${designer.nome} - Checklist de Produção</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
        <style>
          .checkbox-custom {
            width: 24px;
            height: 24px;
            cursor: pointer;
          }
          .task-complete {
            opacity: 0.6;
            background-color: #f0fdf4;
          }
        </style>
    </head>
    <body class="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen">
        <!-- Header -->
        <header class="bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-xl">
            <div class="container mx-auto px-6 py-4">
                <div class="flex items-center justify-between">
                    <div class="flex items-center space-x-4">
                        <a href="/" class="text-white hover:text-blue-200 transition">
                            <i class="fas fa-arrow-left text-2xl"></i>
                        </a>
                        <div>
                            <h1 class="text-3xl font-bold">${designer.nome}</h1>
                            <p class="text-blue-200 text-sm">Checklist de Produção</p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-4">
                        <select id="semana-filter" onchange="loadChecklist()" class="px-4 py-2 rounded-lg bg-white/20 text-white border-2 border-white/30 focus:outline-none focus:border-white">
                            <option value="">Todas as Semanas</option>
                        </select>
                        <button onclick="loadChecklist()" class="bg-white/20 hover:bg-white/30 px-4 py-2 rounded-lg transition">
                            <i class="fas fa-sync-alt"></i>
                        </button>
                    </div>
                </div>
            </div>
        </header>

        <main class="container mx-auto px-6 py-8">
            <!-- Estatísticas -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-blue-500">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-500 text-sm font-medium">Total de Tarefas</p>
                            <p id="stat-total" class="text-3xl font-bold text-gray-800 mt-2">-</p>
                        </div>
                        <div class="bg-blue-100 rounded-full p-3">
                            <i class="fas fa-tasks text-blue-600 text-2xl"></i>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-yellow-500">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-500 text-sm font-medium">Criadas ✓</p>
                            <p id="stat-criadas" class="text-3xl font-bold text-gray-800 mt-2">-</p>
                        </div>
                        <div class="bg-yellow-100 rounded-full p-3">
                            <i class="fas fa-check text-yellow-600 text-2xl"></i>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-green-500">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-500 text-sm font-medium">Aprovadas OK</p>
                            <p id="stat-aprovadas" class="text-3xl font-bold text-gray-800 mt-2">-</p>
                        </div>
                        <div class="bg-green-100 rounded-full p-3">
                            <i class="fas fa-thumbs-up text-green-600 text-2xl"></i>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-purple-500">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-500 text-sm font-medium">Completas</p>
                            <p id="stat-completas" class="text-3xl font-bold text-gray-800 mt-2">-</p>
                        </div>
                        <div class="bg-purple-100 rounded-full p-3">
                            <i class="fas fa-check-double text-purple-600 text-2xl"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Checklist -->
            <div class="bg-white rounded-xl shadow-xl p-6">
                <h2 class="text-2xl font-bold text-gray-800 mb-6">
                    <i class="fas fa-clipboard-check text-blue-600 mr-2"></i>
                    Checklist de Produção
                </h2>
                <div id="checklist" class="space-y-4">
                    <!-- Será preenchido via JS -->
                </div>
            </div>
        </main>

        <script src="https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"></script>
        <script>
          const DESIGNER_ID = ${designer_id};
          const API_URL = '';
          
          async function loadChecklist() {
            try {
              const semana = document.getElementById('semana-filter').value;
              const params = new URLSearchParams();
              if (semana) params.append('semana', semana);
              
              // Carregar checklist
              const checklistRes = await axios.get(\`\${API_URL}/api/designer/\${DESIGNER_ID}/checklist?\${params}\`);
              renderChecklist(checklistRes.data);
              
              // Carregar estatísticas
              const statsRes = await axios.get(\`\${API_URL}/api/designer/\${DESIGNER_ID}/stats?\${params}\`);
              renderStats(statsRes.data);
              
              // Atualizar filtro de semanas
              await updateSemanasFilter(checklistRes.data);
              
            } catch (error) {
              console.error('Erro ao carregar checklist:', error);
              showNotification('Erro ao carregar dados', 'error');
            }
          }
          
          function renderStats(stats) {
            document.getElementById('stat-total').textContent = stats.total_tarefas || 0;
            document.getElementById('stat-criadas').textContent = stats.criadas_ok || 0;
            document.getElementById('stat-aprovadas').textContent = stats.aprovadas_ok || 0;
            document.getElementById('stat-completas').textContent = stats.completas || 0;
          }
          
          function renderChecklist(tasks) {
            const container = document.getElementById('checklist');
            
            if (!tasks || tasks.length === 0) {
              container.innerHTML = '<p class="text-gray-500 text-center py-8">Nenhuma tarefa encontrada</p>';
              return;
            }
            
            // Agrupar por semana
            const grouped = {};
            tasks.forEach(task => {
              if (!grouped[task.semana]) {
                grouped[task.semana] = [];
              }
              grouped[task.semana].push(task);
            });
            
            let html = '';
            Object.keys(grouped).sort((a, b) => b - a).forEach(semana => {
              html += \`
                <div class="mb-6">
                  <h3 class="text-xl font-semibold text-gray-800 mb-4 flex items-center">
                    <i class="fas fa-calendar-week text-blue-600 mr-2"></i>
                    Semana \${semana}
                  </h3>
                  <div class="space-y-2">
                    \${grouped[semana].map(task => {
                      const isComplete = task.criado_check && task.aprovado_ok;
                      return \`
                        <div class="flex items-center p-4 border border-gray-200 rounded-lg hover:shadow-md transition \${isComplete ? 'task-complete' : ''}">
                          <div class="flex items-center space-x-4 flex-1">
                            <!-- Checkbox Criação -->
                            <div class="flex flex-col items-center">
                              <input type="checkbox" 
                                     \${task.criado_check ? 'checked' : ''}
                                     onchange="toggleCriado(\${task.id}, this.checked)"
                                     class="checkbox-custom"
                                     title="Marcar como criada">
                              <span class="text-xs text-gray-500 mt-1">Criada</span>
                            </div>
                            
                            <!-- Info Produto -->
                            <div class="flex-1">
                              <p class="font-semibold text-gray-800">\${task.produto_nome}</p>
                              <p class="text-sm text-gray-500">
                                \${task.data ? new Date(task.data).toLocaleDateString('pt-BR') : ''} 
                                \${task.posicao ? ' - ' + task.posicao : ''}
                              </p>
                            </div>
                            
                            <!-- Quantidade -->
                            <div class="text-center">
                              <p class="text-sm text-gray-500">Qtd</p>
                              <input type="number" 
                                     value="\${task.quantidade_aprovada || 0}"
                                     onchange="updateQuantidade(\${task.id}, this.value)"
                                     class="w-16 px-2 py-1 border border-gray-300 rounded text-center"
                                     min="0">
                            </div>
                            
                            <!-- Posição -->
                            <div class="text-center">
                              <p class="text-sm text-gray-500">Posição</p>
                              <select onchange="updatePosicao(\${task.id}, this.value)"
                                      class="px-2 py-1 border border-gray-300 rounded">
                                <option value="">-</option>
                                <option value="1º" \${task.posicao === '1º' ? 'selected' : ''}>1º</option>
                                <option value="2º" \${task.posicao === '2º' ? 'selected' : ''}>2º</option>
                                <option value="3º" \${task.posicao === '3º' ? 'selected' : ''}>3º</option>
                                <option value="4º" \${task.posicao === '4º' ? 'selected' : ''}>4º</option>
                                <option value="5º" \${task.posicao === '5º' ? 'selected' : ''}>5º</option>
                              </select>
                            </div>
                            
                            <!-- OK Button -->
                            <button onclick="toggleAprovado(\${task.id}, !\${task.aprovado_ok}, document.querySelector('input[onchange*=\"updateQuantidade(\${task.id}\"')[0] ? document.querySelector('input[onchange*=\"updateQuantidade(\${task.id}\"')[0].value : 0)"
                                    class="px-6 py-2 rounded-lg font-semibold transition \${task.aprovado_ok ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-700 hover:bg-green-500 hover:text-white'}">
                              \${task.aprovado_ok ? 'OK ✓' : 'OK'}
                            </button>
                          </div>
                        </div>
                      \`;
                    }).join('')}
                  </div>
                </div>
              \`;
            });
            
            container.innerHTML = html;
          }
          
          async function toggleCriado(id, checked) {
            try {
              await axios.patch(\`\${API_URL}/api/lancamentos/\${id}/check-criado\`, { checked });
              showNotification(checked ? 'Marcado como criada!' : 'Desmarcado', 'success');
              loadChecklist();
            } catch (error) {
              console.error('Erro:', error);
              showNotification('Erro ao atualizar', 'error');
            }
          }
          
          async function toggleAprovado(id, checked, quantidade) {
            try {
              await axios.patch(\`\${API_URL}/api/lancamentos/\${id}/check-aprovado\`, { 
                checked,
                quantidade_aprovada: parseInt(quantidade) || 0
              });
              showNotification(checked ? 'Aprovado! ✓' : 'Aprovação removida', 'success');
              loadChecklist();
            } catch (error) {
              console.error('Erro:', error);
              showNotification('Erro ao atualizar', 'error');
            }
          }
          
          async function updateQuantidade(id, quantidade) {
            try {
              await axios.put(\`\${API_URL}/api/lancamentos/\${id}\`, { 
                quantidade_aprovada: parseInt(quantidade) || 0
              });
              showNotification('Quantidade atualizada!', 'success');
            } catch (error) {
              console.error('Erro:', error);
            }
          }
          
          async function updatePosicao(id, posicao) {
            try {
              await axios.patch(\`\${API_URL}/api/lancamentos/\${id}/posicao\`, { posicao });
              showNotification('Posição atualizada!', 'success');
            } catch (error) {
              console.error('Erro:', error);
            }
          }
          
          function updateSemanasFilter(tasks) {
            const semanas = [...new Set(tasks.map(t => t.semana))].sort((a, b) => b - a);
            const select = document.getElementById('semana-filter');
            const currentValue = select.value;
            
            select.innerHTML = '<option value="">Todas as Semanas</option>' +
              semanas.map(s => \`<option value="\${s}">Semana \${s}</option>\`).join('');
            
            if (currentValue) select.value = currentValue;
          }
          
          function showNotification(message, type = 'info') {
            const colors = {
              success: 'bg-green-500',
              error: 'bg-red-500',
              info: 'bg-blue-500'
            };
            
            const notification = document.createElement('div');
            notification.className = \`fixed top-4 right-4 \${colors[type]} text-white px-6 py-3 rounded-lg shadow-lg z-50 transition-opacity\`;
            notification.textContent = message;
            
            document.body.appendChild(notification);
            
            setTimeout(() => {
              notification.style.opacity = '0';
              setTimeout(() => notification.remove(), 300);
            }, 2000);
          }
          
          // Inicializar
          loadChecklist();
        </script>
    </body>
    </html>
  `)
  */
})


export default app
